// Remplit les paramètres d'une requête compilée, comme doit le faire l'userscript.
//
//   import { fillQuery } from './fill-query.mjs';
//   const kql = fillQuery(rule, { value: '10.1.2.3', t0: '2026-10-08T10:00:00Z', beforeMinutes: 60, host: 'PC01' });
//
// - value : la sélection, validée contre indicators.<type>.patterns ; insérée dans une chaîne verbatim @"…",
//   seuls les guillemets doivent être doublés.
// - t0 : Date ou chaîne ISO 8601 (TimeGenerated de la ligne) ; absent = now() côté KQL.
// - beforeMinutes / afterMinutes : entiers ; absents = fenêtre par défaut de la règle.
// - host : contexte facultatif (règles Processus et Hash).
export function fillQuery(rule, { value, t0, beforeMinutes, afterMinutes, host } = {}, variant = 'query') {
  const verbatim = (s) => String(s ?? '').replace(/"/g, '""');
  const iso = t0 instanceof Date ? t0.toISOString() : (t0 ? new Date(t0).toISOString() : '');
  const int = (n) => (Number.isFinite(Number(n)) && n !== '' && n != null ? String(Math.trunc(Number(n))) : '');
  const values = {
    VALUE: verbatim(value),
    T0: iso,
    BEFORE_MIN: int(beforeMinutes),
    AFTER_MIN: int(afterMinutes),
    HOST: verbatim(host),
  };
  return (rule[variant] || rule.query).replace(/\{\{(VALUE|T0|BEFORE_MIN|AFTER_MIN|HOST)\}\}/g, (_, k) => values[k]);
}

// Vérifie qu'une sélection correspond à au moins un motif de l'indicateur (motifs JS, (?i) accepté en tête).
export function matchesIndicator(indicator, value) {
  return indicator.patterns.some((p) => {
    const ci = p.startsWith('(?i)');
    return new RegExp(ci ? p.slice(4) : p, ci ? 'i' : '').test(String(value).trim());
  });
}
