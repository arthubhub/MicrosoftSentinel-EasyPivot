# sentinel-pivot-rules

Ce dépôt contient 55 règles de pivot KQL pour Microsoft Sentinel et Defender XDR. Elles sont écrites en YAML, puis compilées en JSON pour le menu contextuel de l'userscript : l'utilisateur sélectionne une valeur (IP, compte, e-mail, URL, domaine, machine, processus, application ou hash), choisit une action (Statistics, Pivot ou Timeline) et la requête est injectée dans l'éditeur.

```
npm install
npm run build   # dist/pivot-rules.json, dist/pivot-rules.flat.json, dist/CATALOGUE.md
npm test        # build strict + remplissage des paramètres + revalidation de chaque requête
```

## Organisation

| Dossier | Contenu |
| --- | --- |
| `rules/<indicateur>/*.yaml` | Une règle par fichier (55 au total) |
| `fragments/*.kql` | Fonctions KQL communes, insérées dans les requêtes qui les déclarent dans `uses` |
| `fragments/indicators/*.kql` | Variables dérivées de la valeur sélectionnée (`ValueSam`, `ValueDomain`, `ValueShort`…) |
| `schema/tables.json` | Colonnes de 40 tables, générées depuis la référence officielle Azure Monitor |
| `schema/overrides.json` | Compléments : `AzureDiagnostics` (repris du dépôt Azure-Sentinel) et colonne `Timestamp` des tables Defender |
| `schema/rule.schema.json` | Schéma d'une règle YAML |
| `scripts/build.mjs` | Compilateur |
| `scripts/kql-validator.cjs` | Validation par le service de langage Kusto officiel (`@kusto/language-service-next`) |
| `scripts/fill-query.mjs` | Remplissage des paramètres, à reprendre dans l'userscript |
| `scripts/generate-win-security.mjs` | Génère `fragments/win_security.kql` |
| `scripts/update-schemas.mjs` | Régénère `schema/tables.json` |

## Format d'une règle

```yaml
id: IP-P2                      # préfixe d'indicateur + S/P/T + numéro
name: Comptes connectés depuis l'IP
indicators: [ip]               # url et domain peuvent partager une règle
action: pivot                  # statistics | pivot | timeline
description: >
  Ce que montre la requête.
reading:                       # comment lire le résultat
  decisive: ce qui permet de trancher
  context: ce qui oriente sans conclure
  noise: ce qui est du bruit en production saine
scenarios: [S3, S6]            # scénarios du catalogue
v1: true                       # socle à livrer en premier
window: { before: 24h, after: 1h }   # fenêtre par défaut autour de T0
render: table                  # table | timechart | columnchart | barchart
context: [HOST]                # paramètre de contexte facultatif
uses: [signins, win_security]  # fragments nécessaires (leurs dépendances sont résolues)
query: |
  _Signins(StartTime, EndTime, Value, "")
  | ...
```

Dans `query`, les variables suivantes sont disponibles : `Value`, `T0`, `StartTime`, `EndTime`, les variables de l'indicateur (`ValueUpn`, `ValueSam`, `ValueMail`, `ValueDomain`, `ValueShort`, `ValueFile`, `ValuePath`, `ValueHash`, `ValueApp`), `HostFilter` si `context: [HOST]`, et les fonctions des fragments déclarés.

La macro `XMLFIELD(expr, Nom)` est développée à la compilation en `extract(@'<Data Name="Nom">([^<]*)</Data>', 1, expr)`.

## Paramètres des requêtes compilées

Chaque requête commence par un en-tête de paramètres. Avant substitution, la requête reste du KQL valide et s'exécute avec T0 = `now()` et la fenêtre par défaut.

| Paramètre | Contenu | Si vide ou non remplacé |
| --- | --- | --- |
| `{{VALUE}}` | La sélection, dans une chaîne verbatim `@"…"` : seuls les guillemets sont à doubler | — |
| `{{T0}}` | ISO 8601, idéalement le `TimeGenerated` de la ligne sélectionnée | `now()` |
| `{{BEFORE_MIN}}`, `{{AFTER_MIN}}` | Fenêtre avant et après T0, en minutes | `window` de la règle |
| `{{HOST}}` | Machine de la même ligne (règles Processus et Hash) | toutes les machines |

`scripts/fill-query.mjs` fait la substitution, et `matchesIndicator()` vérifie la sélection contre les motifs de `indicators.<type>.patterns`.

## SecurityEvent et WindowsEvent

Le fragment `_WinSecurity(start, end, ids, term)` renvoie les événements de sécurité Windows avec les mêmes colonnes, quelle que soit la table d'ingestion :

- `SecurityEvent`, alimentée par l'agent AMA ou MMA ;
- `WindowsEvent`, alimentée par Windows Event Forwarding ou une DCR personnalisée, restreinte au fournisseur `Microsoft-Windows-Security-Auditing`.

Chaque champ est pris dans sa colonne s'il est rempli. Sinon, il est extrait du XML brut : `SecurityEvent.EventData` quand l'ingestion n'a pas rempli les colonnes, ou `WindowsEvent.RawEventData` quand l'analyse de `EventData` a échoué. `IpAddress` est nettoyée (`::ffff:`, `-`), `TargetSam` retire le domaine Kerberos et `EventName` et `LogonTypeName` donnent des libellés lisibles. Toutes les règles Windows (IP-T1, AC-P2, MC-P1, MC-P3, PR-P1…) passent par ce fragment.

Pour ajouter un champ, modifiez la liste `F` de `scripts/generate-win-security.mjs` puis lancez `npm run generate:win-security`.

## Sortie

- `dist/pivot-rules.json` contient `indicators` (libellés et motifs de détection), `actions`, `placeholders` et `rules`. Chaque règle porte `id`, `name`, `category`, `indicators`, `action`, `description`, `reading`, `scenarios`, `v1`, `window`, `render`, `tables`, `platforms`, `placeholders`, `query` et, si elle n'utilise que des tables Defender XDR, `queryDefender` (`Timestamp` au lieu de `TimeGenerated`).
- `dist/pivot-rules.flat.json` reprend le format historique de l'userscript : `[{ name, category, description, query }]`.
- `dist/CATALOGUE.md` est le catalogue lisible des règles.

## Plateformes

- `sentinel` : espace de travail Log Analytics.
- `defender-unified` : Advanced Hunting du portail Defender avec l'espace Sentinel rattaché. `TimeGenerated` y existe aussi pour les tables Defender. Choisissez « Set in query » dans le sélecteur de temps, sinon il remplace la fenêtre de la requête.
- `defender` : Defender XDR seul, ce qui suppose d'utiliser `queryDefender`. Cela concerne 22 règles.

Les requêtes à plusieurs tables utilisent `union isfuzzy=true` : une table absente de l'espace est ignorée. Une règle à une seule table échoue si cette table n'est pas ingérée. Le champ `tables` permet à l'userscript de masquer ces règles.

## Validation et limites

- Le build analyse chaque requête avec le service de langage Kusto officiel, sur le schéma de `schema/`. Il signale les erreurs de syntaxe, les tables inconnues et les colonnes inconnues. Une seule erreur fait échouer le build.
- Les requêtes ne sont pas exécutées sur des données réelles. Valeurs d'`ActionType`, noms d'opérations et structure des champs JSON (`AdditionalFields`, `RawEventData`) restent à vérifier dans votre tenant.
- Les règles qui incluent `_WinSecurity` font environ 17 à 21 Ko, dont la majeure partie est le fragment. Pour des requêtes plus courtes, on peut enregistrer les fragments comme fonctions de l'espace Sentinel et ne plus les insérer.

## Mettre à jour les schémas

```
git clone --depth 1 --filter=blob:none --sparse https://github.com/MicrosoftDocs/azure-monitor-docs.git
cd azure-monitor-docs && git sparse-checkout set articles/azure-monitor/reference/tables && cd ..
node scripts/update-schemas.mjs azure-monitor-docs/articles/azure-monitor/reference/tables --add NouvelleTable
```
